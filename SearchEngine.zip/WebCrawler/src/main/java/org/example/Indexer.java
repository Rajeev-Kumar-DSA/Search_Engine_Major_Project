package org.example;

import org.jsoup.nodes.Document;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Indexer {
    // here require three thing -> page title, page link, page text
    static Connection connection = null;

    // make constructor -> parametarised
    Indexer(Document document, String url){
        // select important element of document
        String title = document.title();
        String link = url;
        String text = document.text();

        try{
            // --- Insert command in Table
            // save these element to database
            // get the connection
            connection = DatabaseConnection.getConnection(); /// here calling the databaseConnection class

            // run the insert command for storing the data
            // here data will come dynamically, not store in statically
            // inside preapred -> I passed insert query
            PreparedStatement preparedStatement = connection.prepareStatement("Insert into pages values(?, ?, ?);");
            preparedStatement.setString(1, title);  // each ? -> mark me kya store hoga uska value
            preparedStatement.setString(2, link);
            preparedStatement.setString(3, text);
            preparedStatement.executeUpdate();   // excute the command
        }catch (SQLException sqlException){
            sqlException.printStackTrace();
        }

    }
}
