package org.example;


import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.IOException;
import java.util.HashSet;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
//this will work like crawler bot
public class Crawler {
    HashSet<String> urlSet;
    int MAX_DEPTH = 2;
    // take construcor
    Crawler(){
        // initialize the url set
        urlSet = new HashSet<String>();
    }
    // this function will behave like -> crawler bot
    public void getPageTextsAndLinks(String url, int depth){
        // when already visited current url
        if(urlSet.contains(url)){
            // no need to visite again
            return;
        }
        // when depth will reach maximumDepth -> need to backtrack and return
        if(depth >= MAX_DEPTH){
            return;
        }
        // avoid duplicate
        if(urlSet.add(url)){
            System.out.println(url);
        }
        depth++;

        // here get() -> method will throw exception from document
        try {
            // now I will parse the HTML object page to java object
            // here need one library -> which is Jaoup -> need to install
            // file -> project structure -> libraries -> click one '+' icon + select from Maven ->
            // search Jsoup -> org.jsoup:jsoup:1.15.4 (this library use here for Jsoup)
            // here I will choose Document from Jsoup not choose from javaSwing
            // timeout will help to sleep after 5000 sec -> then move for next link
            Document document = Jsoup.connect(url).timeout(50000).get();
            // here indexer will start -> whatever link got from html object -> store in Database

            // Indexer work start here
            Indexer indexer = new Indexer(document, url);

            // get all link whatever present in current link
            System.out.println(document.title());
            // a[href] -> in html -> <a></a> -> it provide hyperlink
            // <a href ="url"> </a> -> here href will be url ->
            // select all available from current page
            Elements availableLinksOnPage = document.select("a[href]");
            for (Element currentLink : availableLinksOnPage) {
                // here attr -> it will get all href value
                getPageTextsAndLinks(currentLink.attr("abs:href"), depth);
            }
        }
        catch (IOException ioException){
            ioException.printStackTrace();
        }


    }
    public static void main(String[] args) {
        //TIP Press <shortcut actionId="ShowIntentionActions"/> with your caret at the highlighted text
        // to see how IntelliJ IDEA suggests fixing it.

        // --------------------------------------------------------------------------------------------
        // Update Java Security Policy:
        // If you're using an older Java version, you might need to update the security policy.
        // Try adding the following system property when running your Java program:
        //  -Dhttps.protocols=TLSv1.2
        // -------------------------------------------------------------------------------------------------
        System.out.println("Hello and welcome!");
        System.setProperty("https.protocols", "TLSv1.2");
        Crawler crawler = new Crawler();
        crawler.getPageTextsAndLinks("https://www.javatpoint.com", 0);
    }
}