package com.Accio.project;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


/// -----------------------------------------------------------
///  ----- Creating without delete option ------------------
//@WebServlet("/History")  // jo bhi frontend me form name hoga wahi mera webservlet hoga
//public class HistoryServlet extends HttpServlet {
//    protected void doGet(HttpServletRequest request, HttpServletResponse response){
//        // first need to connect with my - mysql database
//        Connection connection = DatabaseConnection.getConnection();
//
//        try{
//            // run the query -> get all the data in table
//            ResultSet resultSet = connection.createStatement().executeQuery("Select * from history;");
//
//            // with help of resultSet I will get all the data from history table
//            // now need to store all data in arrayList
//            ArrayList<HistorySearchStore> results = new ArrayList<HistorySearchStore>();  // HistorySearchStore -> it is calss store the data
//            // one by one value store in my arraylist from resultSet
//            while(resultSet.next()){
//                // make object for HistorySearchStore
//                HistorySearchStore historySearchStore = new HistorySearchStore();
//                historySearchStore.setKeyword(resultSet.getString("keyword")); // this column level from mysql table
//                historySearchStore.setLink(resultSet.getString("link"));
//                results.add(historySearchStore);
//            }
//
//            // -----Displaying results arraylist in consle--------------------------------------
//            for(HistorySearchStore result : results){
//                System.out.println(result.getKeyword() + "\n" + result.getLink() +"\n");
//            }
//
//            request.setAttribute("historyResults", results);  /// setting the result for frontend
//            request.getRequestDispatcher("historyDisplay.jsp").forward(request, response);
//
//
//            // --- here need writter -> with this help we can able to print the value in frontend
//            // using => <% hout.println(result.getKeyword());%>
//
//            response.setContentType("text/html");
//            PrintWriter out = response.getWriter();
//
//        }catch (SQLException sqlException){
//            sqlException.printStackTrace();
//        } catch (ServletException | IOException e) {
//            throw new RuntimeException(e);
//        }
//    }
//}


// ----------------------------------------------------------------------------------
///-----------------------------------------------------------------------------------


@WebServlet("/History")  // jo bhi frontend me form name hoga wahi mera webservlet hoga
public class HistoryServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response){
        // first need to connect with my - mysql database
        Connection connection = DatabaseConnection.getConnection();

        try{
            // run the query -> get all the data in table
            ResultSet resultSet = connection.createStatement().executeQuery("Select * from history;");

            // with help of resultSet I will get all the data from history table
            // now need to store all data in arrayList
            ArrayList<HistorySearchStore> results = new ArrayList<HistorySearchStore>();  // HistorySearchStore -> it is calss store the data
            // one by one value store in my arraylist from resultSet
            while(resultSet.next()){
                // make object for HistorySearchStore
                HistorySearchStore historySearchStore = new HistorySearchStore();
                historySearchStore.setKeyword(resultSet.getString("keyword")); // this column level from mysql table
                historySearchStore.setLink(resultSet.getString("link"));
                results.add(historySearchStore);
            }

            // -----Displaying results arraylist in consle--------------------------------------
            for(HistorySearchStore result : results){
                System.out.println(result.getKeyword() + "\n" + result.getLink() +"\n");
            }

            request.setAttribute("historyResults", results);  /// setting the result for frontend
            request.getRequestDispatcher("historyDisplay.jsp").forward(request, response);


            // --- here need writter -> with this help we can able to print the value in frontend
            // using => <% hout.println(result.getKeyword());%>

            response.setContentType("text/html");
            PrintWriter out = response.getWriter();

        }catch (SQLException sqlException){
            sqlException.printStackTrace();
        } catch (ServletException | IOException e) {
            throw new RuntimeException(e);
        }
    }



    /// ------- for Delete Button -------
    protected void doPost(HttpServletRequest request, HttpServletResponse response) {
        // Get the keyword to delete from request parameter
        String keywordToDelete = request.getParameter("deleteKeyword");  // jo frontend me pass hoga
        System.out.println("Delete link -> " + keywordToDelete);
        // check if parameter is null or empty
        if (keywordToDelete != null && !keywordToDelete.isEmpty()) {
            // Delete the record from the database
            // connect the database --
            Connection connection = DatabaseConnection.getConnection();

            try {
                // Delete Query  -> here my table name is history
                String deleteQuery = "DELETE FROM history WHERE keyword = ?";
                try (PreparedStatement preparedStatement = connection.prepareStatement(deleteQuery)) {
                    preparedStatement.setString(1, keywordToDelete);
                    preparedStatement.executeUpdate(); /// update the execution
                }
            } catch (SQLException sqlException) {
                sqlException.printStackTrace();
            }
        }
        // Redirect back to the history again page after the delete operation
        doGet(request, response);
    }
}
