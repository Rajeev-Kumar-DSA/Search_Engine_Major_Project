package com.Accio.project;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

@WebServlet("/SearchForm")   // jo bhi action me hoga wahi mera path hoga usko hi pass karna hai
// this annotation is called route ->
public class Search extends HttpServlet {
    // when trigger will search method -> doGet will call
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException{
        // ---------------------------------------------------------------------------------
        // -------------- Getting keyword from frontend ---------------------------------
        //        this method will getnearate request and response
        String keyword = request.getParameter("inputKeyword");  /// this will help me get keyword from frontend
        System.out.println(keyword);



        // get the result from the database ->
        Connection connection = DatabaseConnection.getConnection();

        // ---------------------------------------------------------------------------------
        // --------------- we are setting up the connection to database
        try {
            // -----------Making History ------------------------------------
            // whatever I search -> wahi mera history hoga(jo kuch user search karta hai wahi history ke liye hoga)
            PreparedStatement preparedStatement = connection.prepareStatement("Insert into history values (?, ?);");
            preparedStatement.setString(1, keyword);   // jo bhi keyword hoga usko lega
            // this I will get from -> this is my localhost link ->
            preparedStatement.setString(2, "http://localhost:8080/SearchEngine/SearchForm?inputKeyword="+keyword);
            preparedStatement.executeUpdate();


            ///---------------------------------------------------------------------------
            // -------------- Getting results after running the ranking the query -------
            // sql query just change -> instead of java I will my keword value
            // here connection need to handle the exception
            // here connection happend need to add librariy ->  mysql connector J (which is available from device or google)
            ResultSet resultSet = connection.createStatement().executeQuery("SELECT pageTitle, pageLink, " +
                    "(length(lower(pageText)) - length(replace(lower(pageText), '"+keyword.toLowerCase()+"', '')))/length('"+keyword.toLowerCase()+"') \n" +
                    "AS countOccurence FROM pages\n" +
                    "ORDER BY countOccurence DESC \n" +
                    "LIMIT 30;");

            // ----------------------------------------------------------------------------------
            // ------------Transferring values from resultSet to results arrayList --------------
            // take arraylist -> I will store result value from resultSet
            // make user defenied datatype -> here I will store result
            ArrayList<SearchResultStore> results = new ArrayList<SearchResultStore>();  // same like pair class
            while(resultSet.next()){
                SearchResultStore searchResultStore = new SearchResultStore();
                searchResultStore.setTitle(resultSet.getString("pageTitle"));
                searchResultStore.setLink(resultSet.getString("pageLink"));
                results.add(searchResultStore);
            }


            // ----------------------------------------------------------------------------------
            // -----Displaying results arraylist in consle--------------------------------------
            for(SearchResultStore result : results){
                System.out.println(result.getTitle() + "\n" + result.getLink() +"\n");
            }

            /// --- sending the result in frontEND -> i WILL SHOW IN TABULAR FORMATE
            request.setAttribute("resultsList", results);  // -> this request for frowarded to frontend
            // html code -> I will use getAttribute with same name
            // create frontfile for showing the data in tabular formate -> create in webapp
            request.getRequestDispatcher("searchDisplay.jsp").forward(request, response);


            // this will help to interact between frontend to backend
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            // out.println("<h3> This is the keyword you have entered : " +keyword+ "</h3>");
        }catch (SQLException sqlException){
            sqlException.printStackTrace();
        }catch (ServletException servletException){
            servletException.printStackTrace();  /// this exception for handling "request.getRequestDispatcher.forward
        }


    }

}
