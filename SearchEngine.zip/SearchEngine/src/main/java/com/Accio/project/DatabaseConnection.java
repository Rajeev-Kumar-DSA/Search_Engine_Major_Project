package com.Accio.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    // this class will help to create a connection between java code with mySQL query
    // Here we need to create connection instance
    static Connection connection = null;  // always connection will static so I make static method for connection to mysql

    public static Connection getConnection(){
        if(connection != null){
            // when already connected with MYSQL
            // means already connection
            return connection;
        }
        String user = "root";
        String pwd = "RKumar@2024#";
        String databaseName = "searchEngineApp";  // jo bhi create karega database on my sql wahi likhna hai


//        String url = "jdbc:mysql://localhost/"+databaseName+"?user="+user+"&password="+pwd;

//        String url = "jdbc:mysql://localhost:3306/"+databaseName+"?user="+user+"&password="+password+"&useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true&useUnicode=yes&characterEncoding=UTF-8&zeroDateTimeBehavior=CONVERT_TO_NULL&autoReconnect=true&failOverReadOnly=false&maxReconnects=10";
//        System.out.println("Connection URL: " + url);
        return getConnection(user, pwd, databaseName);  // here I will overload this function
    }
    private static Connection getConnection(String user, String pwd, String database){
        // here I will start connection with mysql

        // need to install library -> go to file -> go to project structore ->Library -> click on + icon
        // -> here I will select java(becase mysql will local system) -> select dowloaded file (mySQL connectore - jre)
        // -> then save
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");  /// driver class banega
            // providing the url for connection
//            System.out.println("jdbc:mysql://localhost/"+database+"?user="+user+"&password="+pwd);

            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/searchEngineApp", "root", "RKumar@2024#");

//            System.out.println(connection);
//            return connection;
        }
//        catch (SQLException sqlException){
//            sqlException.printStackTrace();
//        }catch (ClassNotFoundException classNotFoundException){
//            classNotFoundException.printStackTrace();
//        }

        // or second to add both exception in same catch

        catch (SQLException | ClassNotFoundException sqlException){
            sqlException.printStackTrace();
        }
        return connection;
    }
}
